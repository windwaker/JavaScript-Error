<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Github login</name>
   <tag></tag>
   <elementGuidId>96d14c4c-2435-424d-909f-c0cb3457239b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
